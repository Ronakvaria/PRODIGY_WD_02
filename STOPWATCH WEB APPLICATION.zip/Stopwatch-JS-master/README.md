# Stopwatch-JS
A simple JS Stopwatch that uses **set interval** to update display of watch

## Quickstart
   * Clone or Download the repository to your Computer
   * Extract the folder 
   * Open **index.html** and it will open in your Browser
   * You're able to make changes now :)
## FireBase Hosted Link
   https://stopwatch-js-web.web.app 
